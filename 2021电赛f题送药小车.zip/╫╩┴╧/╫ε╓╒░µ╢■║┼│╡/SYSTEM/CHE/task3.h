#ifndef task_3_h__
#define task_3_h__
#include "sys.h"
extern u8 go_flag;
extern u8 bound;
void 	TASK3_GO(void);
void 	CAR_xunji_3(void);
#endif //task_3_h__

