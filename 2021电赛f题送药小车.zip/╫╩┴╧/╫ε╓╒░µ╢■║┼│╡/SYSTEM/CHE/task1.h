#ifndef TASK_1_H
#define TASK_1_H
#include "sys.h"

//#define ZW_90 250//ת��ʱ��
#define zuozhuan 240
#define youzhuan 240
#define ZW_180 550

#define SD_180 (15)
void 	TASK1_GO(void);


#endif //TASK_1_H

