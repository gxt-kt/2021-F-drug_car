#ifndef adc_h__
#define adc_h__
#include "sys.h"
void  Adc_Init(void);
u16 Get_Adc(u8 ch);

#endif //adc_h__

