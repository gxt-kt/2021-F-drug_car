#ifndef V7_DATA_DEAL_H__
#define V7_DATA_DEAL_H__
#include "sys.h"


void USART1_Data_Count(char *buf);


#endif //V7_DATA_DEAL_H__

