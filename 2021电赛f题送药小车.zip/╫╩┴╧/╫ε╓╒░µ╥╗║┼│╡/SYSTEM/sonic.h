#ifndef sonic_h__
#define sonic_h__
#include "sys.h"

void TIM5_sonic_init(u32 arr,u16 psc);

#endif //sonic_h__

