#ifndef exti_h__
#define exti_h__
#include "sys.h"
void exti_init(void);


#endif //exti_h__

