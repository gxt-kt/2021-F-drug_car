#ifndef tim6_h__
#define tim6_h__
#include "sys.h"
extern u16 motor_out;//��ʱ������
void TIM6_INIT(u32 arr,u32 psc);
void TIM7_INIT(u32 arr,u32 psc);
void TIM9_INIT(u32 arr,u32 psc);
#endif //tim6_h__

