#ifndef balance_init_h__
#define balance_init_h__
#include "sys.h"


void balance_init_tim8(void);

#endif //balance_init_h__

