#ifndef key__h_
#define key__h_
#include "sys.h"




void KEY_Init(void);



#endif
