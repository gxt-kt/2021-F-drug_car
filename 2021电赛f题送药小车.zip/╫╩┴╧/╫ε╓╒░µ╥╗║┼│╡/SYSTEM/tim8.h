#ifndef tim8__h__
#define tim8__h__
#include "sys.h"

void tim8_init(u32 arr,u32 psc);
void maiche_init(void);
#endif //tim8__h__

