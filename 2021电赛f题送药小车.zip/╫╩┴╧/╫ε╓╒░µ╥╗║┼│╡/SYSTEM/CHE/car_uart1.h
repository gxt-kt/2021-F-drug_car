#ifndef car_uart1_h_
#define car_uart1_h_
#include "sys.h"
void CAR_UART3_INIT(u32 bound);//PD8,PD9
void CAR_UART4_INIT(u32 bound);//PC10,PC11
void CAR_UART5_INIT(u32 bound);
void CAR_UART6_INIT(u32 bound);
#endif //car_uart1_h_

