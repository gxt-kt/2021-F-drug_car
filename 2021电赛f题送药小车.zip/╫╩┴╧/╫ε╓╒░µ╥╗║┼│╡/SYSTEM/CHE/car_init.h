#ifndef car_init__
#define car_init__
#include "sys.h"

void CAR_init(void);

#endif //car_init__

