#ifndef TASK_1_H
#define TASK_1_H
#include "sys.h"

//#define ZW_90 250//ת��ʱ��
#define zuozhuan 220
#define youzhuan 250
#define ZW_180 600
#define SD_180 (15)
void 	TASK1_GO(void);


#endif //TASK_1_H

