#ifndef task_3_h__
#define task_3_h__
#include "sys.h"


void 	TASK3_GO(void);
#endif //task_3_h__

