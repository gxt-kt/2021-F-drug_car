#ifndef tim14_h__
#define tim14_h__
#include "sys.h"

void TIM14_PWM_Init(u32 arr,u32 psc);

#endif //tim14_h__

