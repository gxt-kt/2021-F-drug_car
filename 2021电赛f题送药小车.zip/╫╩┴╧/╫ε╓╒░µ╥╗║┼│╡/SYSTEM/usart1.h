#ifndef usart1_h__
#define usart1_h__
#include "sys.h"

extern float u1_get_val[];
extern u8 USART1_RX_BUF[];
void usart_1_init(u32 bound);

#endif //usart1_h__

