#ifndef encoder_h__
#define encoder_h__
#include "sys.h"

void ENCODER_1_INIT(void);
void ENCODER_2_INIT(void);
void ENCODER_3_INIT(void);
void ENCODER_4_INIT(void);
#endif //encoder_h__

